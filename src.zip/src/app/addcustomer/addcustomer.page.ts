import { Component, OnInit } from '@angular/core';
import { PostProvider } from '../../providers/post-provider';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.page.html',
  styleUrls: ['./addcustomer.page.scss'],
})
export class AddcustomerPage implements OnInit {

  name_customer: string = "";
  desc_customer: number;
  Form8n9:string;
  EngineeringDesign:string;
  SiteOwner:string;
  ElectricBill:string;
  Declaration:string;
  NemasReport:string;
  FormLP:string;
  STPublicLicense:string;
  LicenseDate:string;
  TnC:string;
  TnCDate:string;
  CDate:string;
  Upload:string;
  NEMCO:string;
  
  id: number;
  constructor(
  	private postPvdr: PostProvider,
  	private router: Router,
  	private actRoute: ActivatedRoute
  ) { }

  ngOnInit() {
  	this.actRoute.params.subscribe((data: any) =>{
  		this.id = data.id;
  		this.name_customer = data.name;
		  this.desc_customer = data.desc;
		  this.Form8n9=data.Form8n9;
		  this.EngineeringDesign=data.EngineeringDesign;
		  this.SiteOwner=data.SiteOwner;
		  this.ElectricBill=data.ElectricBill;
		  this.Declaration=data.Declaration;
		  this.NemasReport=data.NemasReport;
		  this.FormLP=data.FormLP;
		  this.STPublicLicense=data.STPublicLicense;
		  this.LicenseDate=data.LicenseDate;
		  this.TnC=data.TnC;
		  this.TnCDate=data.TnCDate;
		  this.CDate=data.CDate;
		  this.Upload=data.Upload;
		  this.NEMCO=data.NEMCO;
  		console.log(data);
  	});
  }

  createdProses(){
  	return new Promise(resolve => {
  		let body = {
  			aksi : 'add',
  			name_customer : this.name_customer,
			  desc_customer : this.desc_customer,
			  Form8n9:this.Form8n9,
			  EngineeringDesign:this.EngineeringDesign,
			  SiteOwner:this.SiteOwner,
			  ElectricBill:this.ElectricBill,
			  Declaration:this.Declaration,
			  NemasReport:this.NemasReport,
			  FormLP:this.FormLP,
			  STPublicLicense:this.STPublicLicense,
			  LicenseDate:this.LicenseDate,
			  TnC:this.TnC,
			  TnCDate:this.TnCDate,
			  CDate:this.CDate,
			  Upload:this.Upload,
			  NEMCO:this.NEMCO,
  		};

  		this.postPvdr.postData(body, 'proses-api.php').subscribe(data => {
  			this.router.navigate(['/customer']);
  			console.log('OK');
  		});
  	});

  }

  updateProses(){
  	return new Promise(resolve => {
  		let body = {
  			aksi : 'update',
  			customer_id : this.id,
  			name_customer : this.name_customer,
			  desc_customer : this.desc_customer,
			  Form8n9:this.Form8n9,
			  EngineeringDesign:this.EngineeringDesign,
			  SiteOwner:this.SiteOwner,
			  ElectricBill:this.ElectricBill,
			  Declaration:this.Declaration,
			  NemasReport:this.NemasReport,
			  FormLP:this.FormLP,
			  STPublicLicense:this.STPublicLicense,
			  LicenseDate:this.LicenseDate,
			  TnC:this.TnC,
			  TnCDate:this.TnCDate,
			  CDate:this.CDate,
			  Upload:this.Upload,
			  NEMCO:this.NEMCO,
			  
  		};

  		this.postPvdr.postData(body, 'proses-api.php').subscribe(data => {
  			this.router.navigate(['/customer']);
  			console.log('OK');
  		});
  	});

  }

}
