import { Component, OnInit } from '@angular/core';
import { PostProvider } from '../../providers/post-provider';
import { Router, ActivatedRoute } from '@angular/router';
import { ThrowStmt } from '@angular/compiler';
// interface allData {
//   name_customer: string,
//   desc_customer: string,
//   Form8n9:string,
//   EngineeringDesign:string,
//   SiteOwner:string,
//   ElectricBill:string,
//   Declaration:string,
//   NemasReport:string,
//   FormLP:string,
//   STPublicLicense:string,
//   LicenseDate:string,
//   TnC:string,
//   TnCDate:string,
//   CDate:string,
//   Upload:string,
//   NEMCO:string,
//   id: number,

// };
@Component({
  selector: 'app-showcustomer',
  templateUrl: './showcustomer.page.html',
  styleUrls: ['./showcustomer.page.scss'],
})
export class ShowcustomerPage implements OnInit {
  // allDatas:allData[]=[];
  name_customer: string;
  desc_customer: string;
  Form8n9:string;
  EngineeringDesign:string;
  SiteOwner:string;
  ElectricBill:string;
  Declaration:string;
  NemasReport:string;
  FormLP:string;
  STPublicLicense:string;
  LicenseDate:string;
  TnC:string;
  TnCDate:string;
  CDate:string;
  Upload:string;
  NEMCO:string;
  id: number;
  str:string;

  constructor(
  	private router: Router,
  	private postPvdr: PostProvider,
  	private actRoute: ActivatedRoute
  ) { }

  ngOnInit() {
  	this.actRoute.params.subscribe((data: any) =>{
  		this.id = data.id;
  		this.name_customer = data.name;
      this.desc_customer = data.desc;
      this.Form8n9=data.Form8n9;
      this.EngineeringDesign=data.EngineeringDesign;
      this.SiteOwner=data.SiteOwner;
      this.ElectricBill=data.ElectricBill;
      this.Declaration=data.Declaration;
      this.NemasReport=data.NemasReport;
      this.FormLP=data.FormLP;
      this.STPublicLicense=data.STPublicLicense;
      this.LicenseDate=data.LicenseDate;
      this.TnC=data.TnC;
      this.TnCDate=data.TnCDate;
      this.CDate=data.CDate;
      this.Upload=data.Upload;
      this.NEMCO=data.NEMCO;
      console.log(data);
      console.log("color testing");
      document.getElementById("kWp").style.color="black";
      
      if(this.Form8n9=='Pending'){
      document.getElementById("Form89").style.color = "red";
      }else if(this.Form8n9=='No Need'){
        document.getElementById("Form89").style.color = "purple";

      }else{
        document.getElementById("Form89").style.color = "green";

      };

      if(this.EngineeringDesign=='Pending'){
        document.getElementById("ED").style.color = "red";
        }else if(this.EngineeringDesign=='No Need'){
          document.getElementById("ED").style.color = "purple";
  
        }else{
          document.getElementById("ED").style.color = "green";
  
        };

        if(this.SiteOwner=='Pending'){
          document.getElementById("SO").style.color = "red";
          }else if(this.SiteOwner=='No Need'){
            document.getElementById("SO").style.color = "purple";
    
          }else{
            document.getElementById("SO").style.color = "green";
    
          };
  
          if(this.ElectricBill=='Pending'){
            document.getElementById("EB").style.color = "red";
            }else if(this.ElectricBill=='Done'){
              document.getElementById("EB").style.color = "green";
      
            }else{
              document.getElementById("EB").style.color = "grey";
      
            };

            if(this.Declaration=='Pending'){
              document.getElementById("DL").style.color = "red";
              }else{
                document.getElementById("DL").style.color = "green";
        
              };

              if(this.NemasReport=='Pending'){
                document.getElementById("NR").style.color = "red";
                }else if(this.NemasReport=='No Need'){
                  document.getElementById("NR").style.color = "purple";
          
                }else{
                  document.getElementById("NR").style.color = "green";
          
                };

                if(this.FormLP=='Pending'){
                  document.getElementById("FLP").style.color = "red";
                  }else if(this.FormLP=='No Need'){
                    document.getElementById("FLP").style.color = "purple";
            
                  }else{
                    document.getElementById("FLP").style.color = "green";
            
                  };

                  if(this.STPublicLicense=='Pending'){
                    document.getElementById("STPL").style.color = "red";
                    }else if(this.STPublicLicense=='No Need'){
                      document.getElementById("STPL").style.color = "purple";
              
                    }else{
                      document.getElementById("STPL").style.color = "green";
              
                    };

                    if(this.LicenseDate=='(N.A)'){
                      document.getElementById("LD").style.color = "purple";
                      }else{
                        document.getElementById("LD").style.color = "green";
                
                      };



                    if(this.TnC=='Pending'){
                      document.getElementById("TnCPR").style.color = "red";
                      }else if(this.TnC=='No Need'){
                        document.getElementById("TnCPR").style.color = "purple";
                
                      }else{
                        document.getElementById("TnCPR").style.color = "green";
                
                      };

                      if(this.TnCDate=='(N.A)'){
                        document.getElementById("TnCPD").style.color = "purple";
                        }else{
                          document.getElementById("TnCPD").style.color = "green";
                  
                        };

                      if(this.CDate=='WaitingNEM'){
                        document.getElementById("CDate").style.color = "red";
                        document.getElementById("CDate").style.fontSize = "15px";
                        }else{
                          document.getElementById("CDate").style.color = "green";
                  
                        };

                        if(this.Upload=='Pending'){
                          document.getElementById("UPLOAD").style.color = "red";
                          }else{
                            document.getElementById("UPLOAD").style.color = "green";
                    
                          };

                          if(this.NEMCO=='Pending'){
                            document.getElementById("NEMCO").style.color = "red";
                            }else{
                              document.getElementById("MEMCO").style.color = "green";
                      
                            };

                    

    });
    

  }
  
  TextChange(){
  
    // if(document.getElementById("Form8n9").innerHTML=='Pending'){
    //   document.getElementById("Form8n9").className = "red-text";
    // }else{
    //   document.getElementById("Form8n9").className = "green-text";
    // }

  }
}
